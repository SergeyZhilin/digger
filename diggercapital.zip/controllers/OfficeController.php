<?php

namespace app\controllers;

class OfficeController extends MainController
{
    //public $layout = '//layouts/office';

}